package com.example.weighttrackingapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void onButtonClick(View v) {

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 0);
        } else {
            sendSMS();
        }
    }

    public void LoginClick(View v){
        EditText usernameText = (EditText) findViewById(R.id.editTextUsername);
        EditText passwordText = (EditText) findViewById(R.id.editTextTextPassword);
        String nameTextValue = usernameText.getText().toString();
        String passwordTextValue = passwordText.getText().toString();
        if(checkLogin(nameTextValue, passwordTextValue)){
            setContentView(R.layout.display_main);
        }
    }

    private boolean checkLogin(String username, String password){
        UserDao userDao = db.userDao();
        User user;
        user = userDao.findByName(username, password);
        return user != null;
    }

    private void createUser(String username, String password){
        UserDao userDao = db.userDao();
        User user = new User();
        user.userName = username;
        user.password = password;
        userDao.insertAll(user);
    }

    private void sendSMS() {

        EditText phoneText = findViewById(R.id.editTextPhone);
        String phoneNumber = String.valueOf(phoneText.getText());

        String message = "This is an example of an SMS sent to number: " + phoneNumber;

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent to: " + phoneNumber, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed to Send", Toast.LENGTH_SHORT).show();
        }
    }
}
